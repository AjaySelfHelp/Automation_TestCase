﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_SentEmail
{
    class SentEmailInformation
    {
        public void SentEmail()
        {
            //Thread.Sleep(2000);
           // string emailFrom = "ab366665@gmail.com";
            string emailFrom = "ajaykumar@aureoleinc.com";
            string password = "Ajaykumar123";
            string emailTo = "ajaymca14326@gmail.com,ajaykumar@aureoleinc.com";
            string subject = "Automation_Report";
            string tbody = "Hello, I'm just writing this to say Hi!";

            MailMessage msg = new MailMessage(emailFrom, emailTo, subject, tbody);
            string[] filePaths = Directory.GetFiles(@"C:\AutoTestResults\", "*.txt");
            foreach (string fileName in filePaths){
                msg.Attachments.Add(new Attachment(fileName));
            }
            msg.IsBodyHtml = true;
            SmtpClient sc = new SmtpClient("mail.exclusivehosting.net");//Office email id
      //    SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);//using gmail id
            sc.UseDefaultCredentials = false;
            NetworkCredential cre = new NetworkCredential(emailFrom, password);
            sc.Credentials = cre;
            sc.EnableSsl = true;
            sc.Send(msg);
        }

        public void SendingEmail()
        {
                Thread.Sleep(1000);
                string fromAddress = ConfigurationSettings.AppSettings["fromAddress"].ToString().Trim();
                string mailPassword = ConfigurationSettings.AppSettings["password"].ToString().Trim();
                string smtpServer = ConfigurationSettings.AppSettings["smtpServer"].ToString().Trim();
                string emailTo = ConfigurationSettings.AppSettings["toAddress"].ToString().Trim();
                string fromDisplayName = "Automation_Report";
                string tbody = "Please find the attached today’s Date  ["+ DateTime.Now.ToString("d/MM/yyyy")+"]  Test Automation Execution report. Thanks";            

                SmtpClient smtpClient = new SmtpClient(smtpServer);
                smtpClient.UseDefaultCredentials = false;
                NetworkCredential nc = new NetworkCredential(fromAddress, mailPassword);
                smtpClient.Credentials = nc;

                MailMessage msg = new MailMessage(fromAddress, emailTo, fromDisplayName, tbody);
                string path = ConfigurationSettings.AppSettings["path"].ToString().Trim();

                string[] filePaths = Directory.GetFiles(@""+path, "*.txt");
                foreach (string fileName in filePaths)
                {
                msg.Attachments.Add(new Attachment(fileName));
                }
                smtpClient.Send(msg);
                msg.Dispose();
                Thread.Sleep(3000);
       }
    }
}
