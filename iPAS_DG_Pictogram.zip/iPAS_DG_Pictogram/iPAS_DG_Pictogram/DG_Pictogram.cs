﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_DG_Pictogram
{
    class DG_Pictogram
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        DGClassInfoLanguageTemplate languageResouce = new DGClassInfoLanguageTemplate();
        public void pictogramInfo()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkAdmin");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnklabelDb");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkDGPictogram");
            auto.MouseClick();
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*Here Checking how Many record is there befor add */

            var totalbefore = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string tot = totalbefore.ToString().Trim();
            int totalbeforerecord = Convert.ToInt32(totalbefore);

            Thread.Sleep(mid);
            Click<HtmlFileInput>(PropertyType.Id, "fileToUpload");
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "filePath"));
            }
            catch (Exception e) { }
            mparentwindow = null;
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtDGClassCode", ExcelDataTable.ReadData(1, "DG_Class_Code"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddDGClass");
            Thread.Sleep(mid);
            ////************Validation using Assert Method Here **************///
            var data1 = window.ExecuteScript("var data=document.getElementById('spnDGClassError').innerHTML;  return  data");
            string successMsg1 = data1.ToString().Trim();
            Assert.AreEqual(languageResouce.Msg_DGClassAddedSuccessfully, successMsg1, successMsg1);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            var afterTotal = window.ExecuteScript("var data=document.getElementById('spnTotalRecords').innerHTML;  return  data");
            string afterTot = afterTotal.ToString().Trim();
            int afterTotalRecords = Convert.ToInt32(afterTot);
            totalbeforerecord = totalbeforerecord + 1;
            Thread.Sleep(mid);
            Assert.AreEqual(afterTotalRecords, totalbeforerecord, "Total Record value Not Proper");
            Thread.Sleep(min);
        }
        public void seachAndUpdate()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "DG_Class_Code"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('lblSearchMsg').innerHTML;  return  data");
            string successMsg1 = data1.ToString();
            Assert.AreEqual("", successMsg1, successMsg1);
            Thread.Sleep(min);

            /*******************Here clicking of Edit Button***************/
            //var EditId1 = window.ExecuteScript("var data=document.querySelectorAll('i'); return data;");
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[11].id;");
            //string id = EditId.ToString();
            //id = "'" + id + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 45;
            //auto.MouseMove(Xco, Yco);
            //Thread.Sleep(min);
            //auto.MouseClick();
            //Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "DG_Class_Code"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 75;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);

            /***********Here Update the Data**************/
            Click<HtmlFileInput>(PropertyType.Id, "fileToUpload");
            try
            {
                PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "updateFilePath"));
                //Thread.Sleep(mid);
            }
            catch (Exception e) { }
            /**********Here Validate image uploading Valid or Not*****************/
            var data2 = window.ExecuteScript("var data=document.getElementById('spnDGClassError').innerHTML;  return  data");
            string successMsg2 = data2.ToString().Trim();
            Assert.AreEqual(languageResouce.MsgDGClassImageAddedSuccessfully, successMsg2, successMsg2);
            mparentwindow = null;
            Click<HtmlEdit>(PropertyType.Id, "txtDGClassCode");
            try
            {
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "txtDGClassCode", ExcelDataTable.ReadData(1, "UpdateDG_Class_Code"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnAddDGClass");
            Thread.Sleep(mid);
            ////************Validation using Assert Method Here **************///
            var data = window.ExecuteScript("var data=document.getElementById('spnDGClassError').innerHTML;  return  data");
            string successMsg = data.ToString().Trim();
            Assert.AreEqual(languageResouce.Msg_DGClassUpdatedSuccessfully, successMsg, successMsg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void searchAndDelete()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "UpdateDG_Class_Code"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data1 = window.ExecuteScript("var data=document.getElementById('lblSearchMsg').innerHTML;  return  data");
            string successMsg1 = data1.ToString();
            Assert.AreEqual("", successMsg1, successMsg1);

            /*******************Here Click on the Delete Button***************/
            //var EditId = window.ExecuteScript("var data=document.querySelectorAll('i'); return data[12].id;");
            //string id = EditId.ToString();
            //id = "'" + id + "'";
            //Thread.Sleep(mid);
            //var xCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.left");
            //var yCoodinate = window.ExecuteScript("var data1=document.getElementById(" + id + "); var rect = data1.getBoundingClientRect(); return  rect.top");

            //string x = xCoodinate.ToString();
            //string y = yCoodinate.ToString();
            //double x1 = Convert.ToDouble(x);
            //double y1 = Convert.ToDouble(y);
            //int Xco = Convert.ToInt32(x1);
            //int Yco = Convert.ToInt32(y1);
            ////Make sure Browser Window is Maximize
            //// Xco = Xco;
            //Yco = Yco + 60;
            //auto.MouseMove(Xco, Yco);
            //auto.MouseClick();
            //Thread.Sleep(min);
            //auto.Send("{ENTER}");
            //Thread.Sleep(min);
            //auto.Send("{F5}");
            //Thread.Sleep(mid);
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlSpan>(PropertyType.InnerText, ExcelDataTable.ReadData(1, "UpdateDG_Class_Code"));
            int Mx1 = auto.MouseGetPosX();
            int My1 = auto.MouseGetPosY();
            Mx1 = Mx1 - 55;
            My1 = My1 - 3;
            Thread.Sleep(max);
            auto.MouseMove(Mx1, My1);
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{ENTER}");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);

            /*************Here Apply validation to Check Data is Deleted or Not****************/

            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtSearch", ExcelDataTable.ReadData(1, "UpdateDG_Class_Code"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            ////************Here validate on the Search TextBoX Data is Enter or Not**************///
            var data = window.ExecuteScript("var data=document.getElementById('lblSearchMsg').innerHTML;  return  data");
            string successMsg = data.ToString();
            Assert.AreEqual("", successMsg, successMsg);
            Thread.Sleep(min);
            bool b1 = SearchNoData();
            Assert.IsTrue(b1, "Data is Not Deleted");
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnShowAll");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void pageNavigator()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            int i=1;
            try
            {
                var pageCount = window.ExecuteScript("var data=document.getElementById('ctl01_divPager').getElementsByTagName('a');  return  data.length");
                string len = pageCount.ToString();
                int length = Convert.ToInt32(len);
                for (i = 1; i <= length; i++)
                {
                    string tagId = "ctl01_hrefNum" + i;
                    Click<HtmlDiv>(PropertyType.Id, "footer");
                    Thread.Sleep(min);
                    Click<HtmlHyperlink>(PropertyType.Id, tagId);
                    Thread.Sleep(min);
                    validation(i);
                    tagId = "";
                }
            }
            catch (Exception e) {

                string error = "Data is Not there On Navigate page No:" + i;
                Assert.IsTrue(false, error);
            }
            
            Thread.Sleep(min);
        }
        public void validation(int i)
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var len = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_dgClassBody').getElementsByTagName('td');  return  data.length");
            string length = len.ToString().Trim();
            int Data = Convert.ToInt32(length);
            bool flag =true;
            if (Data == 0)
                flag =false;

            string error = "Data is Not there On Navigate page No:" + i;
            Assert.IsTrue(flag, error);
        }

        public bool SearchNoData()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var data = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_dgClassBody').getElementsByTagName('span')[0];  return  data.innerHTML");
            string successMsg = data.ToString().Trim();
            bool b1 = successMsg.Equals(languageResouce.Msg_NoRecordFound);
            return b1;
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }

}
