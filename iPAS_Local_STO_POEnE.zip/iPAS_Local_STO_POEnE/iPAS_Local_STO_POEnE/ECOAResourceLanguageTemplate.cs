﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ImportPOEnE
{
    class ECOAResourceLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; }
        }

        static string resMsg_successfullyUploadedECOA = string.Empty;
        public string Msg_successfullyUploadedECOA
        {
            get { return resMsg_successfullyUploadedECOA; }
            set { resMsg_successfullyUploadedECOA = value; }
        }
        static string resMsg_Confirm = string.Empty;
        public string Msg_Confirm
        {
            get { return resMsg_Confirm; }
            set { resMsg_Confirm = value; }
        }


        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.ECOAResourceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.ECOAResourceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.ECOAResourceVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.ECOAResourceKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.ECOAResourceJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.ECOAResourceID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.ECOAResourceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_successfullyUploadedECOA = rm.GetString("resMsg_successfullyUploadedECOA", ci).Trim();
            resMsg_Confirm = rm.GetString("resMsg_Confirm", ci).Trim();

        }

    }
}
