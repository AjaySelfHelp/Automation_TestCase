﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ImportPOEnE
{
    class SyncDataResouceLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;
        static string resMsg_SyncingSuccessfullyCompleted = string.Empty;
        public string Msg_SyncingSuccessfullyCompleted
        {
            get { return resMsg_SyncingSuccessfullyCompleted; }
            set { resMsg_SyncingSuccessfullyCompleted = value; }
        }
       public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.SyncDataResouceCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.SyncDataResouceTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }         
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.SyncDataResouceEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_SyncingSuccessfullyCompleted = rm.GetString("resMsg_SyncingSuccessfullyCompleted", ci).Trim();
        }
    }
}
