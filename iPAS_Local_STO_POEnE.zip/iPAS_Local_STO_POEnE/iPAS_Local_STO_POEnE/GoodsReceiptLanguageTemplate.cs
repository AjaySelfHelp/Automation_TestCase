﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace iPAS_ImportPOEnE
{
    class GoodsReceiptLanguageTemplate
    {
        static CultureInfo ci = null;
        static ResourceManager rm = null;

        static string resMsg_LabelsAreCreated = string.Empty;
        public string Msg_LabelsAreCreated
        {
            get { return resMsg_LabelsAreCreated; }
            set { resMsg_LabelsAreCreated = value; }
        }
        static string resMsg_SampleLabelCreatedSuccessFully = string.Empty;
        public string Msg_SampleLabelCreatedSuccessFully
        {
            get { return resMsg_SampleLabelCreatedSuccessFully; }
            set { resMsg_SampleLabelCreatedSuccessFully = value; }
        }
        static string resMsg_DoYouWantToCompleteGoodsReceipt = string.Empty;
        public string Msg_DoYouWantToCompleteGoodsReceipt
        {
            get { return resMsg_DoYouWantToCompleteGoodsReceipt; }
            set { resMsg_DoYouWantToCompleteGoodsReceipt = value; }
        }
        static string resMsg_HAveYouCompletedGR = string.Empty;
        public string Msg_HAveYouCompletedGR
        {
            get { return resMsg_HAveYouCompletedGR; }
            set { resMsg_HAveYouCompletedGR = value; }
        }
        static string resMsg_NoRecordsFound = string.Empty;
        public string Msg_NoRecordsFound
        {
            get { return resMsg_NoRecordsFound; }
            set { resMsg_NoRecordsFound = value; } 
        }
        static string resMsg_Yes = string.Empty;
        public string Msg_Yes
        {
            get { return resMsg_Yes; }
            set { resMsg_Yes = value; }
        }//

        static string resMsg_Ok = string.Empty;
        public string Msg_Ok
        {
            get { return resMsg_Ok; }
            set { resMsg_Ok = value; }
        }
        static string resMsg_BatchNumber10DigitValidation = string.Empty;
        public string Msg_BatchNumber10DigitValidation
        {
            get { return resMsg_BatchNumber10DigitValidation; }
            set { resMsg_BatchNumber10DigitValidation = value; }
        }

        public static void messageResource(string languageCode)
        {
            if (languageCode == "zh-CN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.GoodsReceiptCN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "th-TH")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.GoodsReceiptTH", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "vi-VN")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.GoodsReceiptVN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ko-KR")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.GoodsReceiptKR", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "ja-JP")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.GoodsReceiptJP", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else if (languageCode == "id-ID")
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.GoodsReceiptID", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
            else
            {
                ci = new CultureInfo(languageCode);
                rm = new ResourceManager("iPAS_Local_STO_POEnE.resources.GoodsReceiptEN", Assembly.GetExecutingAssembly());
                messageInitialize();
            }
        }
        public static void messageInitialize()
        {
            resMsg_LabelsAreCreated = rm.GetString("resMsg_LabelsAreCreated", ci).Trim();
            resMsg_SampleLabelCreatedSuccessFully = rm.GetString("resMsg_SampleLabelCreatedSuccessFully", ci).Trim();
            resMsg_DoYouWantToCompleteGoodsReceipt = rm.GetString("resMsg_DoYouWantToCompleteGoodsReceipt", ci).Trim();
            resMsg_HAveYouCompletedGR = rm.GetString("resMsg_HAveYouCompletedGR", ci).Trim();
            resMsg_NoRecordsFound = rm.GetString("resMsg_NoRecordsFound", ci).Trim();
            resMsg_Yes = rm.GetString("resMsg_Yes", ci).Trim();
            resMsg_Ok = rm.GetString("resMsg_Ok", ci).Trim();
            resMsg_BatchNumber10DigitValidation = rm.GetString("resMsg_BatchNumber10DigitValidation", ci).Trim();



        }
    }
}
