﻿using AutoItX3Lib;
using DataDrivenTesting;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_ImportPOEnE
{
    class GoodsReceiptDetails
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        GoodsReceiptLanguageTemplate GRLanguageResource = new GoodsReceiptLanguageTemplate();

        public void goodsReceiptInfo(string TokenNo)
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkStockReceipt");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid*2);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkGoodsReceipt");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid * 2);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            string TokenNoEntry = "Entry Num:" + " " + TokenNo;
            try {
                //Click<HtmlCustom>(PropertyType.Id, "ctl01_btnView");
               
                Click<HtmlDiv>(PropertyType.InnerText, TokenNoEntry);
                Thread.Sleep(min);
                int x = auto.MouseGetPosX();
                int y = auto.MouseGetPosY();
                x = x + 1020;
                auto.MouseMove(x, y);
                y = y + 65;
                auto.MouseMove(x, y);
                auto.MouseClick();
                Thread.Sleep(min);
                auto.MouseClick();
            }
            catch (Exception e) {
                Click<HtmlDiv>(PropertyType.DispalyText, TokenNoEntry);
                Thread.Sleep(min);
                int x = auto.MouseGetPosX();
                int y = auto.MouseGetPosY();
                x = x + 1020;
                auto.MouseMove(x, y);
                y = y + 65;
                auto.MouseMove(x, y);
                auto.MouseClick();
                Thread.Sleep(min);
                auto.MouseClick();
            }
            /***************Now Coming inside GoodsReceipt page ***************/
            Thread.Sleep(mid*2);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try {
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtProductionDate");
                Thread.Sleep(min);
                auto.Send("{BACKSPACE 10}");//Existing Data Deletion
                auto.Send("{DEL 10}");
                EnterText<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtProductionDate", ExcelDataTable.ReadData(1, "Date"));
                Thread.Sleep(min);
            }catch(Exception e) { }
            int batchLength = ExcelDataTable.ReadData(1, "Batch_No").Length;
            string maxBatchNo = string.Empty;
            try {
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtBatchNumber");
                Thread.Sleep(min);
                auto.Send("{BACKSPACE 20}");//Existing Data Deletion
                auto.Send("{DEL 20}");
                EnterText<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtBatchNumber", ExcelDataTable.ReadData(1, "Batch_No"));
                Thread.Sleep(min);
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtLotNumber");
                Thread.Sleep(max);
                var maxBatchMSG = window.ExecuteScript("var data=document.getElementById('divAlertMessage').innerHTML; return data;");
                maxBatchNo=maxBatchMSG.ToString().Trim();
                maxBatchNo=maxBatchNo.Replace("&amp;","&");
                int len = maxBatchNo.Length;
                if (GRLanguageResource.Msg_BatchNumber10DigitValidation!= maxBatchNo){
                    string pagePath = " GoodsReceipt_Msg_BatchNumberMAX10DigitValidation";
                    screenShot(pagePath);
                }
            }
            catch (Exception e) { }
            Assert.AreEqual(GRLanguageResource.Msg_BatchNumber10DigitValidation, maxBatchNo, maxBatchNo);
                Thread.Sleep(max);
                auto.Send("{ENTER}");
                Thread.Sleep(min);
                auto.Send("{ENTER}");
                Thread.Sleep(max * 2);
            bool empty = false;
            var validateBatchTexBox = window.ExecuteScript("var data=document.getElementById('goodsReceiptMaterialDetails_txtBatchNumber').value; return data;");
            var validateLotTexBox = window.ExecuteScript("var data=document.getElementById('goodsReceiptMaterialDetails_txtLotNumber').value; return data;");
            string bat=validateLotTexBox.ToString().Trim();
            if (validateBatchTexBox == null || validateBatchTexBox.ToString() == "" && validateLotTexBox == null || validateLotTexBox.ToString() == "" && bat != ExcelDataTable.ReadData(1, "Batch_No").Trim())
            {
                empty = true;
                string pagePath = " validateBatchTexBoxAndValidateLotTexBoxError";
                screenShot(pagePath);
            }
            Assert.IsFalse(empty, "Batch Number OR Lot Number Not Generated");
            //if (batchLength < 10)
            //{
            //    try
            //    {
            //        Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtLotNumber");
            //        Thread.Sleep(min);
            //        auto.Send("{BACKSPACE 20}");//Existing Data Deletion
            //        auto.Send("{DEL 20}");
            //        EnterText<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtLotNumber", ExcelDataTable.ReadData(1, "Lot_Number"));
            //        Thread.Sleep(min);
            //    }
            //    catch (Exception e) { }
            //}
            Thread.Sleep(min);
            Click<HtmlDiv>(PropertyType.Id, "footer");
            Thread.Sleep(min);
            bool coa = SearchPaperWork();
            try
            {
                if (coa)//coa==true then You Click Yes other Wise Skip
                {
                    Click<HtmlButton>(PropertyType.Id, "goodsReceiptMaterialDetails_btnECOAYES");
                }
            }catch(Exception e) { }
            bool ComparePallet = SearchComparePallets();
            try {
                if (ComparePallet)//ComparePallet==true then you click both Yes button other Wise Skip
                {
                    Click<HtmlButton>(PropertyType.Id, "goodsReceiptMaterialDetails_btnPalletYes");
                    Click<HtmlButton>(PropertyType.Id, "goodsReceiptMaterialDetails_btnPackYes");
                }
            }catch(Exception e) { }
            Thread.Sleep(min);
            try
            {
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtPackSize");
                auto.Send("{BACKSPACE 5}");//Existing Data Deletion
                auto.Send("{DEL 5}");
                EnterText<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtPackSize", ExcelDataTable.ReadData(1, "Pack_size"));
            }catch(Exception e) { }
            try {
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_goodsReceiptPallteInfo_1_txtNoOfPacks");
                auto.Send("{BACKSPACE 5}");//Existing Data Deletion
                auto.Send("{DEL 5}");
                EnterText<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_goodsReceiptPallteInfo_1_txtNoOfPacks", ExcelDataTable.ReadData(1, "Number_of_Packs"));
            }
            catch (Exception e) { }
            try {
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_goodsReceiptPallteInfo_1_txtNoOfPallets");
                auto.Send("{BACKSPACE 5}");//Existing Data Deletion
                auto.Send("{DEL 5}");
                EnterText<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_goodsReceiptPallteInfo_1_txtNoOfPallets", ExcelDataTable.ReadData(1, "Number_of_Pallets"));

            } catch(Exception e) { }
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "goodsReceiptMaterialDetails_drpLabelType", ExcelDataTable.ReadData(1, "Label_Type"));
            }
            catch (Exception e) { }
                try
                {
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtNumberOfLabel");
                auto.Send("{BACKSPACE 5}");//Existing Data Deletion
                auto.Send("{DEL 5}");
                EnterText<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtNumberOfLabel", ExcelDataTable.ReadData(1, "NLabel"));
                }catch (Exception e) { }
                try {
                Thread.Sleep(min);
            EnterText<HtmlComboBox>(PropertyType.Id, "goodsReceiptMaterialDetails_drpPrinterDetails", ExcelDataTable.ReadData(1, "PrinterName"));
            }catch (Exception e) { }
            Thread.Sleep(min);
            try
            {
                Thread.Sleep(min);
                Click<HtmlDiv>(PropertyType.Id, "footer");
                Thread.Sleep(min);
            }
            catch (Exception e)
            {
                Thread.Sleep(min);
                Click<HtmlEdit>(PropertyType.Id, "goodsReceiptMaterialDetails_txtTotalQuantity");
                Thread.Sleep(mid);
            }            
            //Here Clicking Save print Button 
            Click<HtmlButton>(PropertyType.Id, "goodsReceiptMaterialDetails_btnSaveAndPrint");
            ////*******Here Apply Validation Label is Created Or Not**********/////
            Thread.Sleep(max*3);
            var AlertMsg = window.ExecuteScript("var data=document.getElementById('divAlertMessage').innerHTML; return data;");
            string msg = AlertMsg.ToString();
            if (GRLanguageResource.Msg_LabelsAreCreated != msg)
            {
                string pagePath = " GoodsReceipt_LabelsAreNotCreated";
                screenShot(pagePath);
            }
            Assert.AreEqual(GRLanguageResource.Msg_LabelsAreCreated, msg, msg);
            Thread.Sleep(min);
            try
            {             
            Click<HtmlButton>(PropertyType.DispalyText,GRLanguageResource.Msg_Ok);
            }
            catch (Exception e)
            {
                try
                {
                    Click<HtmlButton>(PropertyType.InnerText, GRLanguageResource.Msg_Ok);
                }
                catch (Exception e1)
                {
                    try {
                        Click<HtmlButton>(PropertyType.TagInstance,"26");
                    }catch(Exception e2)
                    {
                        auto.Send("{ENTER}");
                        Thread.Sleep(min);
                        auto.Send("{ENTER}");
                    }
                   
                }               
            }
            /*************Here Click the Take Simaple Button*********************/
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid*2);
            string successMsg = string.Empty;
            try
            {
                Click<HtmlInputButton>(PropertyType.Name, "goodsReceiptMaterialSummary_1$ctl01");                
                EnterText<HtmlEdit>(PropertyType.Id, "ContentPlaceHolder1_txtNumberOfLabel", ExcelDataTable.ReadData(1, "NLabel"));  
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPrinterDetails", ExcelDataTable.ReadData(1, "PrinterName"));
                
                Thread.Sleep(mid);
                Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnPrint");
                Thread.Sleep(max);
                //////*******Here Apply Validation Label is Created successfully Or Not///////////////
               
                 var spnMsg = window.ExecuteScript("var data=document.getElementById('spnErrorMessage').innerHTML; return data;");
                 successMsg = spnMsg.ToString().Trim();
                if (GRLanguageResource.Msg_SampleLabelCreatedSuccessFully != successMsg)
                {
                    string pagePath = " GoodsReceipt_SampleLabelCreatedNotSuccessFully";
                    screenShot(pagePath);
                }
            }
            catch (Exception e) { }
            Assert.AreEqual(GRLanguageResource.Msg_SampleLabelCreatedSuccessFully, successMsg, successMsg);
                /*************Here close the alert window*******************/
                Thread.Sleep(min);
                Click<HtmlCustom>(PropertyType.Id, "lnkCloseBtn");
                          
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(max);
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnReceiveMaterials");
            Thread.Sleep(mid*2);
            var recMsg = window.ExecuteScript("var data=document.getElementById('divAlertMessage').innerHTML; return data;");
            string rMsg = recMsg.ToString().Trim();
            if (GRLanguageResource.Msg_DoYouWantToCompleteGoodsReceipt != rMsg)
            {
                string pagePath = " GoodsReceipt_DoYouWantToCompleteGoodsReceipt_NotProper";
                screenShot(pagePath);
            }
            Assert.AreEqual(GRLanguageResource.Msg_DoYouWantToCompleteGoodsReceipt, rMsg, rMsg);
            Thread.Sleep(mid);
            try
            {
                Click<HtmlButton>(PropertyType.InnerText, GRLanguageResource.Msg_Yes);
            }
            catch (Exception e) {
                try {
                    Click<HtmlButton>(PropertyType.TagInstance, "26");
                }catch(Exception e1)
                {
                    try {
                        Click<HtmlButton>(PropertyType.DispalyText, GRLanguageResource.Msg_Yes);
                        auto.Send("{ENTER}");
                    }catch(Exception e2)
                    {
                        auto.Send("{ENTER}");
                    }
                }
            }
            Thread.Sleep(max*10);
            var recMsg1 = window.ExecuteScript("var data=document.getElementById('divAlertMessage').innerHTML; return data;");
            string rMsg1 = recMsg1.ToString().Trim();
            string newUpadte = GRLanguageResource.Msg_HAveYouCompletedGR.Replace("[XXX]", ExcelDataTable.ReadData(1, "PurchaseOrder_No"));
            if (newUpadte != rMsg1)
            {
                string pagePath = " GoodsReceipt_NotCompleted";
                screenShot(pagePath);
            }
            Assert.AreEqual(newUpadte, rMsg1, rMsg1);
            Thread.Sleep(min);
            try
            {
                Click<HtmlButton>(PropertyType.InnerText,GRLanguageResource.Msg_Yes);
            }
            catch(Exception e)
            {
                try
                {
                    Click<HtmlButton>(PropertyType.DispalyText, GRLanguageResource.Msg_Yes);

                }
                catch (Exception e1) {
                    try {

                        Click<HtmlButton>(PropertyType.TagInstance, "34");
                    }catch(Exception e2) {
                        auto.Send("{ENTER}");
                    }
                }
            }
            Thread.Sleep(max);
            try
            {
                Click<HtmlButton>(PropertyType.TagInstance, "22");
                Thread.Sleep(min);
                Click<HtmlButton>(PropertyType.TagInstance, "23");
                Thread.Sleep(min);
            }
            catch (Exception e) { }
            try {
                Click<HtmlButton>(PropertyType.Id, "btnSaveVendorQuestions");
            }catch(Exception e) { }
        }
        public bool SearchPaperWork()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var coa = window.ExecuteScript("var data=document.getElementById('goodsReceiptMaterialDetails_divECOA').style.getPropertyValue('display'); return data;");
            string data = coa.ToString();
            bool b1 = data.Equals("block");
            return b1;
        }
        public bool SearchComparePallets()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(500);
            var coa = window.ExecuteScript("var data=document.getElementById('goodsReceiptMaterialDetails_divCompareBlock').style.getPropertyValue('display'); return data;");
            string data = coa.ToString();
            bool b1 = data.Equals("block");
            return b1;
        }
        public bool search(string id)
        {
            BrowserWindow window = new BrowserWindow();
            var data1 = window.ExecuteScript("var data=document.getElementById(" + id + ").getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(GRLanguageResource.Msg_NoRecordsFound);
            return b1;
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }       
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
            {
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            }
            else if (type == PropertyType.DispalyText)
            {
                genericControl.SearchProperties[HtmlButton.PropertyNames.DisplayText] = propertyvalue;
            }
            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance,
            DispalyText
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
