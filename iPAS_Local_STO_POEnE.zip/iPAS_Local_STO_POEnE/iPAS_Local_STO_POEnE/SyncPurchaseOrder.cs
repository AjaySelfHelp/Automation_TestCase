﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_ImportPOEnE;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_Local_STO_POEnE
{
    class SyncPurchaseOrder
    {
       
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        SyncDataResouceLanguageTemplate syncLanguageResource = new SyncDataResouceLanguageTemplate();
        //ImportedPOResourceLanguageTemplate importLanguageResource = new ImportedPOResourceLanguageTemplate();
        //CalenderResourceLanguageTemplate CalenderlanguageResource = new CalenderResourceLanguageTemplate();
        public void syncPO()
        {
           
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkSync");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(max);
            //Click<HtmlRadioButton>(PropertyType.Id, "rdbDeliveryOrder");
            //Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtTypeValue", ExcelDataTable.ReadData(1, "PurchaseOrder_No"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSyncSingle");
            Thread.Sleep(max * 3);
            var data = window.ExecuteScript("var data=document.getElementById('spnSingleSyncMessage').innerHTML; return data;");
            string msg = data.ToString().Trim();
            Thread.Sleep(min);
            Assert.AreEqual(syncLanguageResource.Msg_SyncingSuccessfullyCompleted, msg, msg);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void PurchaseOrderCalendar()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkStockReceipt");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkCalendar");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.MouseClick();
            Thread.Sleep(mid * 2);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            string PO = ExcelDataTable.ReadData(1, "PurchaseOrder_No");
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtPurchaseOrder", ExcelDataTable.ReadData(1, "PurchaseOrder_No"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlInputButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(mid);
            var data = window.ExecuteScript("var data=document.getElementById('spnSearchError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            Thread.Sleep(min);
            Assert.AreEqual("", msg, msg);
            Thread.Sleep(mid);
            bool b1 = search();
            Assert.IsTrue(b1, "Purchase Order is Not schedule For Today Date");
            Thread.Sleep(mid*2);
            // var table = window.ExecuteScript(@"var data=document.getElementById('ContentPlaceHolder1_ucDayViewCalendar_dayViewTable').innerHTML;
            var tableRowNo = window.ExecuteScript(@"var data = myFunction();
                                             function myFunction() {
                                             var rowNo;
                                             var po=document.getElementById('txtPurchaseOrder').value; 
                                             var a = parseInt(po); 
                                             var table = document.getElementById('ContentPlaceHolder1_ucDayViewCalendar_dayViewTable');
                                             var tableRows = table.rows.length;  
                                             for (i = 0; i < tableRows; i++){ 
                                             var rowCells = table.rows.item(i).cells;
                                             for(var j = 0; j < rowCells.length; j++){   
    
                                             if(a == rowCells.item(j).innerText){
                                             rowNo=i;
                                                     }
                                                    }
                                                   }
                                            rowNo=rowNo+1;                                       
                                            return rowNo;
                                                  }
                                            return data; ");
            string rowNo = tableRowNo.ToString().Trim();
            string imgID = "'" + "dayViewRowControl_" + rowNo + "_statusImage" + "'";
            var imgSrc = window.ExecuteScript(@"var data=document.getElementById(" + imgID + ").src; return data; ");
            if (imgSrc != null) { 
            string imgPath=imgSrc.ToString().Trim();
            string imgName=imgPath.Substring(40);
            Assert.AreEqual("NotStarted.gif", imgName, imgPath);
           //Assert.AreEqual("YellowRounded.gif", imgName, imgPath);
            }
            Thread.Sleep(mid*2);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public string manageTrucks()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkStockReceipt");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkManageTruck");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddNewTruck");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "PONum_1", ExcelDataTable.ReadData(1, "PurchaseOrder_No"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAddPONumber");
            Thread.Sleep(mid);

            var data = window.ExecuteScript("var data=document.getElementById('submitErrorMessage').innerHTML; return data;");
            string msg = data.ToString().Trim();
            Thread.Sleep(min);
            Assert.AreEqual("", msg, msg);
            //*********************Here Check TokenNum is Generated Or Not***********************//
            var data1 = window.ExecuteScript("var data=document.getElementById('lblTokenNum').innerHTML; return data;");
            string msg1 = data1.ToString().Trim();
            Thread.Sleep(min);
            Assert.IsNotNull(data1, "Token Number Is Not Generated");
            Thread.Sleep(min);
            mparentwindow = null;
            /******************Fill Driver Information*********************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtDriverLicence", ExcelDataTable.ReadData(1, "Driver_Licence_No"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtDriverName", ExcelDataTable.ReadData(1, "Driver_Name"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtTruckNum", ExcelDataTable.ReadData(1, "Truck_No"));
            }
            catch (Exception e) { }
            Thread.Sleep(min);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnAssignGateAndPrintToken");
            Thread.Sleep(min);
            mparentwindow = null;
            try
            {
                EnterText<HtmlComboBox>(PropertyType.Id, "ContentPlaceHolder1_drpPrinterDetails", ExcelDataTable.ReadData(1, "printer"));
                Click<HtmlCustom>(PropertyType.Id, "printerSettingSave");

            }
            catch (Exception e) { }
            Thread.Sleep(min);
            mparentwindow = null;
            Click<HtmlCustom>(PropertyType.Id, "ctl01_ctl00_assignGate");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid*2);
            Click<HtmlCustom>(PropertyType.Id, "ContentPlaceHolder1_btnBack");
            Thread.Sleep(mid);
            auto.Send("{F5}");
            Thread.Sleep(mid*2);
            return msg1;
        }
        public bool search()
        {
            BrowserWindow window = new BrowserWindow();
            Thread.Sleep(1000);
            var tbl = window.ExecuteScript("var data=document.getElementById('ContentPlaceHolder1_ucDayViewCalendar_dayViewTable').innerHTML; return data;");

            string PurchaseOrder = ExcelDataTable.ReadData(1, "PurchaseOrder_No").Trim();
            string data = tbl.ToString();
            bool b1 = data.Contains(PurchaseOrder);
            return b1;
        }
        //public bool search(string id)
        //{
        //    BrowserWindow window = new BrowserWindow();
        //    var data1 = window.ExecuteScript("var data=document.getElementById(" + id + ").getElementsByTagName('span')[0];  return  data.innerHTML");
        //    string msg1 = data1.ToString().Trim();
        //    bool b1 = msg1.Equals(importLanguageResource.Msg_NoRecordsFound);//Here use calender REouce Data
        //    return b1;
        //}
        private void EnterText<T>(PropertyType id, string v, object p)
        {
            throw new NotImplementedException();
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }
    }
}
