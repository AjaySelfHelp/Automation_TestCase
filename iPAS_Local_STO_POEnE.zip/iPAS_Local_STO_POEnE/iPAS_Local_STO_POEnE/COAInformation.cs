﻿using AutoItX3Lib;
using DataDrivenTesting;
using iPAS_ImportPOEnE;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iPAS_Local_STO_POEnE
{
    class COAInformation
    {
        string minsleep = ConfigurationSettings.AppSettings["min"];
        string midsleep = ConfigurationSettings.AppSettings["mid"];
        string maxsleep = ConfigurationSettings.AppSettings["max"];
        ECOAResourceLanguageTemplate COALanguageResource = new ECOAResourceLanguageTemplate();
        public void COA_Info()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "lnkStockReceipt");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlHyperlink>(PropertyType.Id, "ContentPlaceHolder1_lnkeCOA");
            auto.MouseClick();
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            /****************Here Uploading the the COA info*****************/
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNumber", ExcelDataTable.ReadData(1, "Material_No"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBatchNumber", ExcelDataTable.ReadData(1, "Batch_No"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtOrderNumber", ExcelDataTable.ReadData(1, "Order_No"));
            }
            catch (Exception e) { }
            Click<HtmlFileInput>(PropertyType.Id, "ContentPlaceHolder1_uploadFile");
            PathEnterText<WinEdit>(PropertyType.Name, "File name:", ExcelDataTable.ReadData(1, "FilePath"));
            /*******************Here apply already exist for this material, batch & Order Number..!! **************/
            //try
            //{
            //    Thread.Sleep(mid);
            //    mparentwindow = null;
            //    Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSaveCOA");

            //}catch(Exception e) { }
            //mparentwindow = null;
            Thread.Sleep(mid);
            /********Here apply validation COA_info Uploading Successfully*******/
            var data = window.ExecuteScript("var data=document.getElementById('lblUploadError').innerHTML; return data;");
            string msg = data.ToString().Trim();
            if (COALanguageResource.Msg_successfullyUploadedECOA!= msg)
            {
                string pagePath = " successfullyNotUploadedECOA";
                screenShot(pagePath);
            }
            Thread.Sleep(mid);
            Assert.AreEqual(COALanguageResource.Msg_successfullyUploadedECOA, msg, msg);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void approvingCOA()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNum", ExcelDataTable.ReadData(1, "Material_No"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBatchNum", ExcelDataTable.ReadData(1, "Batch_No"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtOrderNum", ExcelDataTable.ReadData(1, "Order_No"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Click<HtmlCustom>(PropertyType.Id, "ctl01_lnkChangeStatus");
            Thread.Sleep(mid);
            int x = auto.MouseGetPosX();
            int y = auto.MouseGetPosY();
            x = x - 35;
            auto.MouseMove(x, y);
            Thread.Sleep(min);
            auto.MouseClick();
            try
            {
                Thread.Sleep(min);
                Click<HtmlButton>(PropertyType.InnerText, COALanguageResource.Msg_Confirm);
            }
            catch (Exception e) { }
            auto.Send("{ENTER}");
            //Click<HtmlCustom>(PropertyType.TagInstance, "21");
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public void CheckApproveStatus()
        {
            BrowserWindow window = new BrowserWindow();
            AutoItX3 auto = new AutoItX3();
            int min = Convert.ToInt32(minsleep);
            int mid = Convert.ToInt32(midsleep);
            int max = Convert.ToInt32(maxsleep);
            Thread.Sleep(min);
            auto.Send("{F5}");
            Thread.Sleep(mid);
            Click<HtmlCheckBox>(PropertyType.Id, "ContentPlaceHolder1_chkApproved");
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtMaterialNum", ExcelDataTable.ReadData(1, "Material_No"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtBatchNum", ExcelDataTable.ReadData(1, "Batch_No"));
            }
            catch (Exception e) { }
            try
            {
                EnterText<HtmlEdit>(PropertyType.Id, "txtOrderNum", ExcelDataTable.ReadData(1, "Order_No"));
            }
            catch (Exception e) { }
            Click<HtmlButton>(PropertyType.Id, "ContentPlaceHolder1_btnSearch");
            Thread.Sleep(max);

            /////////Assertion to Validate  that Material is Approved or Not //////////

            var data = window.ExecuteScript("var data=document.getElementById('ctl01_spnStatus').className; return data;");
            string msg = data.ToString().Trim();
            if (msg != "icon-ok-circle green")
            {
                string pagePath = " MaterialNotApproved";
                screenShot(pagePath);
            }
            Assert.AreEqual("icon-ok-circle green", msg, "Material Not Approved");
            Thread.Sleep(max);
            auto.Send("{F5}");
            Thread.Sleep(mid);
        }
        public bool search(string id)
        {
            BrowserWindow window = new BrowserWindow();
            var data1 = window.ExecuteScript("var data=document.getElementById(" + id + ").getElementsByTagName('span')[0];  return  data.innerHTML");
            string msg1 = data1.ToString().Trim();
            bool b1 = msg1.Equals(COALanguageResource.Msg_successfullyUploadedECOA);
            return b1;
        }
        public void screenShot(string imgName)
        {
            BrowserWindow window = new BrowserWindow();
            string path = ConfigurationSettings.AppSettings["ScreenShot"];
            try
            {
                window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
                Image image = window.CaptureImage();
                image.Save(path + "\\" + imgName + ".jpeg", ImageFormat.Jpeg);
                image.Dispose();
            }
            catch (Exception e) { }
            Console.WriteLine("Screen Shot is Avaliable in " + path + "\t" + "Folder");
        }
        private void EnterText<T>(PropertyType id, string v, object p)
        {
            throw new NotImplementedException();
        }
        public void WindowButtonClick<T>(PropertyType type, string propertyvalue) where T : WinControl
        {
            WinControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Name)
                genericControl.SearchProperties[WinControl.PropertyNames.Name] = propertyvalue;

            Mouse.Click(genericControl);
        }
        public void PathEnterText<T>(PropertyType type, string propertyvalue, string text) where T : WinEdit
        {
            WinEdit genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            genericControl.FilterProperties[WinEdit.PropertyNames.Name] = propertyvalue;
            AutoItX3 auto = new AutoItX3();
            auto.WinActivate("Choose File to Upload");
            auto.Send(text);
            auto.Send("{ENTER}");
            Thread.Sleep(1000);
        }
        public void Click<T>(PropertyType type, string propertyvalue) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });

            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;
            else if (type == PropertyType.InnerText)
            {
                genericControl.SearchProperties[HtmlControl.PropertyNames.InnerText] = propertyvalue;
            }
            else if (type == PropertyType.TagInstance)
            {
                genericControl.FilterProperties[HtmlControl.PropertyNames.TagInstance] = propertyvalue;

            }
            Mouse.Click(genericControl);
        }
        public void EnterText<T>(PropertyType type, string propertyvalue, string text) where T : HtmlControl
        {
            HtmlControl genericControl = (T)Activator.CreateInstance(typeof(T), new object[] { ParentWindow });
            if (type == PropertyType.Id)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Id] = propertyvalue;
            else if (type == PropertyType.Name)
                genericControl.SearchProperties[HtmlControl.PropertyNames.Name] = propertyvalue;

            Keyboard.SendKeys(genericControl, text);

        }
        private BrowserWindow mparentwindow { get; set; }
        public enum PropertyType
        {
            Id,
            Name,
            InnerText,
            TagInstance
        }
        public BrowserWindow TopParentWindow()
        {

            BrowserWindow window = new BrowserWindow();
            window.SearchProperties[UITestControl.PropertyNames.ClassName] = BrowserWindow.CurrentBrowser.ToString();
            return window;
        }
        public BrowserWindow ParentWindow
        {
            get
            {
                if (this.mparentwindow == null)
                {
                    this.mparentwindow = TopParentWindow();
                }
                return this.mparentwindow;
            }
        }




    }
}
